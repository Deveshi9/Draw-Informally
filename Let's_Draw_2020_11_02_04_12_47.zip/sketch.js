function setup() {
  createCanvas(1000, 1000);
}

function draw() {
  if (mouseIsPressed) {
    fill("yellow");
  } else {
    fill("aqua");
  }
  ellipse(mouseX, mouseY, 80, 80);
}
